# A good start testset for gistops

... no documentation sorry ... :(