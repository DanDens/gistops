# How to zip all files recursively including hidden files

Use the following commmand
> zip -r -q test_git-ls-attr.zip * .* -x "../*"
