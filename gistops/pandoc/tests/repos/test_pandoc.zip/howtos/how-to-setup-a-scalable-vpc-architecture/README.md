# Building a Modular and Scalable Virtual Network Architecture with Amazon VPC
See https://docs.aws.amazon.com/quickstart/latest/vpc/architecture.html

![](2022-10-28%2019_26_26-snaphot.png)
